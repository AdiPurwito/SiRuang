package model;

public interface BookingHandler {
    void prosesBooking();
}
